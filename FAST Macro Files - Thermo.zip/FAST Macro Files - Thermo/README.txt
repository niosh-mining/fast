NOTE:

These files may be updated over time. Be sure to check back on the FAST GitHub for changes and updates to these files.
Also, these files MAY need to be modified based on the version of the instrument software that you have installed.


File descriptions:

1.	iD1_Transmission.exp (Thermo experiment file, establishes the correct parameters/settings)
2.	Silica_int.qnt (Thermo method file, determines the areas associated with the Q, K, M, etc. values and processes the raw spectrum files)
