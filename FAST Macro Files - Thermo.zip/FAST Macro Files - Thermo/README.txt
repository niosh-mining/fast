NOTE:

These files may be updated over time. Be sure to check back on the FAST GitHub for changes and updates to these files.
Also, these files MAY need to be modified based on the version of the instrument software that you have installed.


File descriptions:

1.	iD1_Transmission.exp (Thermo experiment file, establishes the correct parameters/settings)

Recommended saved location and procedure to use:
Save this file in c:\my documents\omnic\param. 
In Omnic, select this file in the Experiment: dropdown menu (at the top).

2.	Silica_int.qnt (Thermo method file, determines the areas associated with the Q, K, M, etc. values and processes the raw spectrum files)

Recommended saved location and procedure to use:
Save this file in c:\my documents\omnic\quant. 
In TQ Analyst, select File >> Open Method. Select this file.

