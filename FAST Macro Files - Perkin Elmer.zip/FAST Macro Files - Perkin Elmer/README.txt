NOTE:

These files may be updated over time. Be sure to check back on the FAST GitHub for changes and updates to these files.
Also, these files MAY need to be modified based on the version of the instrument software that you have installed.


File descriptions:

1.	Calcite.eqn (Perkin Elmer equation for C value � will likely be removed at some point)
2.	Dolomite.eqn (Perkin Elmer equation for D value � will likely be removed at some point)
3.	Kaolin.eqn (Perkin Elmer equation for K value)
4.	Microcline.eqn (Perkin Elmer equation for M value � will likely be removed at some point)
5.	Silica.eqn (Perkin Elmer equation for Q value � will likely be removed at some point)
6.	Silica Est.prc (Perkin Elmer macro file, processes the raw spectrum files)
