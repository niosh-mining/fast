NOTE:

These files may be updated over time. Be sure to check back on the FAST GitHub for changes and updates to these files.
Also, these files MAY need to be modified based on the version of the instrument software that you have installed.


File descriptions:

1.	Calcite.eqn (Perkin Elmer equation for C value � will likely be removed at some point)

Recommended saved location and procedure to use:
Save this file in c:\pel_data\equations. 
No additional steps are needed to use this file; it is incorporated into the Silica Est macro.

2.	Dolomite.eqn (Perkin Elmer equation for D value � will likely be removed at some point)

Recommended saved location and procedure to use:
Save this file in c:\pel_data\equations.
No additional steps are needed to use this file; it is incorporated into the Silica Est macro.

3.	Kaolin.eqn (Perkin Elmer equation for K value)

Recommended saved location and procedure to use:
Save this file in c:\pel_data\equations.
No additional steps are needed to use this file; it is incorporated into the Silica Est macro.

4.	Microcline.eqn (Perkin Elmer equation for M value � will likely be removed at some point)

Recommended saved location and procedure to use:
Save this file in c:\pel_data\equations.
No additional steps are needed to use this file; it is incorporated into the Silica Est macro.


5.	Silica.eqn (Perkin Elmer equation for Q value � will likely be removed at some point)

Recommended saved location and procedure to use:
Save this file in c:\pel_data\equations.
No additional steps are needed to use this file; it is incorporated into the Silica Est macro.

6.	Silica Est.prc (Perkin Elmer macro file, processes the raw spectrum files)

Recommended saved location and procedure to use:
Save this file in c:\pel_data\macros. 
In Spectrum, select Process >> Macros. Select this file.


