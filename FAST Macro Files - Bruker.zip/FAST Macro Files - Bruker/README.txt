NOTE:

These files may be updated over time. Be sure to check back on the FAST GitHub for changes and updates to these files.
Also, these files MAY need to be modified based on the version of the instrument software that you have installed.


File descriptions:

1.	Trans.XPM (Bruker experiment file, establishes the correct parameters/settings)
2.	silica.int (Bruker integration file, determines the areas associated with the Q, K, M, etc. values)
3.	silica_est.mtx (Bruker macro file, processes the raw spectrum file)
4.	silica_report.art (Bruker report template, generates the file imported into FAST)