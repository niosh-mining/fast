NOTE:

These files may be updated over time. Be sure to check back on the FAST GitHub for changes and updates to these files.
Also, these files MAY need to be modified based on the version of the instrument software that you have installed.


File descriptions:

1.	Trans.XPM (Bruker experiment file, establishes the correct parameters/settings)

Recommended saved location and procedure to use:
Save this file in c:\Bruker\Opus\XPM. 
In Opus, select Measure >> Setup Measurement Parameter. In the “Experiment” field on the “Basic” tab, select this file.


2.	silica.int (Bruker integration file, determines the areas associated with the Q, K, M, etc. values)

Recommended saved location and procedure to use:
Save this file in c:\Bruker\Opus\Methods.
In Opus, select Evaluate >> Integration >> Load integration method. Select this file.


3.	silica_est.mtx (Bruker macro file, processes the raw spectrum file)

Recommended saved location and procedure to use:
Save this file in c:\Bruker\Opus\Macro. 
In Opus, select Setup >> Setup User Macro List and select this file in the “Path and file name” field. Refer to the Opus documentation and Help file for more guidance on adding/creating a macro.


4.	silica_report.art (Bruker report template, generates the file imported into FAST)

Recommended saved location and procedure to use:
Save this file in c:\Bruker\Opus.
In Opus, select Print >> Generate Analysis Report. Choose “Select Template File” and select this file.
