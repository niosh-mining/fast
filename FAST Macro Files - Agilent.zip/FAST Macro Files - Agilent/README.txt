NOTE:

These files may be updated over time. Be sure to check back on the FAST GitHub for changes and updates to these files.
Also, these files MAY need to be modified based on the version of the instrument software that you have installed.


File descriptions:

1.	Transmission_test(2).a2m (Agilent experiment file, establishes the correct parameters/settings)
2.	Peak-areas.def (Agilent integration file, determines the areas associated with the Q, K, M, etc. values)