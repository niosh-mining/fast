NOTE:

These files may be updated over time. Be sure to check back on the FAST GitHub for changes and updates to these files.
Also, these files MAY need to be modified based on the version of the instrument software that you have installed.


File descriptions:

1.	Transmission_test(2).a2m (Agilent experiment file, establishes the correct parameters/settings)

Recommended saved location and procedure to use:
Save this file in c:\Program Files\Agilent\MicroLab PC\methods.
In MicroLab PC, select Methods. Select this file.


2.	Peak-areas.def (Agilent integration file, determines the areas associated with the Q, K, M, etc. values)

Recommended saved location and procedure to use:

Save this file in c:\ProgramData\Agilent\Resolutions\Sample Data. 
In Resolutions Pro, select Analysis >> Peak Options >> New Peak Template (all spectra) >> Create a set from file >> Browse. Select this file.
