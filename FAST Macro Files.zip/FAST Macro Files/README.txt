NOTE:

These files may be updated over time. Be sure to check back on the FAST GitHub for changes and updates to these files.
Also, these files MAY need to be modified based on the version of the instrument software that you have installed.


File descriptions:

1.	Trans.XPM (Bruker experiment file, establishes the correct parameters/settings)
2.	silica.int (Bruker integration file, determines the areas associated with the Q, K, M, etc. values)
3.	silica_est.mtx (Bruker macro file, processes the raw spectrum file)
4.	silica_report.art (Bruker report template, generates the file imported into FAST)
5.	iD1_Transmission.exp (Thermo experiment file, establishes the correct parameters/settings)
6.	Silica_int.qnt (Thermo method file, determines the areas associated with the Q, K, M, etc. values and processes the raw spectrum files)
7.	Calcite.eqn (Perkin Elmer equation for C value � will likely be removed at some point)
8.	Dolomite.eqn (Perkin Elmer equation for D value � will likely be removed at some point)
9.	Kaolin.eqn (Perkin Elmer equation for K value)
10.	Microcline.eqn (Perkin Elmer equation for M value � will likely be removed at some point)
11.	Silica.eqn (Perkin Elmer equation for Q value � will likely be removed at some point)
12.	Silica Est.prc (Perkin Elmer macro file, processes the raw spectrum files)
13.	Transmission_test(2).a2m (Agilent experiment file, establishes the correct parameters/settings)
14.	Peak-areas.def (Agilent integration file, determines the areas associated with the Q, K, M, etc. values)